create schema bdgame;
use bdgame;
CREATE TABLE `bdgame`.`user` (
  `id` VARCHAR(45) NOT NULL,
  `passwd` VARCHAR(45) NOT NULL,
  `ip` VARCHAR(45) NULL,
  `group` INT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE);
  select * from user;
insert into user
  values('twstella@naver.com','98stella*',NULL,NULL);
insert into user
values('ann4913@naver.com','yeji4913',NULL,NULL);
insert into user
values('hyounso2@naver.com','hyounso2',NULL,NULL);
insert into user
values('jhlee@jejunu.ac.kr','2twins',NULL,NULL);
insert into user
values('twstella624@gmail.com','sl28721839',NULL,NULL);
delete from user
where id='twstella@naver.com';
delete from user
where id='twstella';