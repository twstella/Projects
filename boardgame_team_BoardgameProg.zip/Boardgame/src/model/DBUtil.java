package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
public class DBUtil {
	public static ResultSet findUser(Connection con,String uid) throws SQLException{
		String sqlSt="SELECT passwd FROM user WHERE id=";
		Statement st;
		ResultSet rs=null;
		try {
			st=con.createStatement();
			if(st.execute(sqlSt+"'"+uid+"'")) {
				return st.getResultSet();
			}
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static boolean checkAccount(Connection con,String uid) throws SQLException{
		String sqlSt="SELECT * FROM user WHERE id=";
		Statement st;
		ResultSet rs=null;
		try {
			st=con.createStatement();
			rs=st.executeQuery(sqlSt+"'"+uid+"'");
			if(rs!=null) {
				if(rs.next()) {
					System.out.println("has id");
					return false;
				}
				else return true;
			}
			else {
				System.out.println("null result set");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return true;
	}
	public static void addAccount(Connection con,String uid,String pw) throws SQLException {
		PreparedStatement pstmt=null;
		try {
			con.setAutoCommit(false);
			pstmt=con.prepareStatement("Insert INTO user Values(?,?,?,?)");
			pstmt.setString(1, uid);
			pstmt.setString(2, pw);
			pstmt.setString(3, null);
			pstmt.setString(4, null);
			pstmt.executeUpdate();
			con.commit();
			con.setAutoCommit(true);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(pstmt!=null) pstmt.close();
		}
	}
	public static void modPasswd(Connection con,String uid,String pw) throws SQLException {
		Statement stmt=null;
		try {
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet uprs=stmt.executeQuery("Select * from user where id="+"'"+uid+"'");
			while(uprs.next()) {
				String old=uprs.getString("passwd");
				uprs.updateString("passwd",pw);
				uprs.updateRow();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(stmt!=null) stmt.close();
		}
	}
	public static void modIp(Connection con,String uid,String ip) throws SQLException {
		Statement stmt=null;
		try {
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet uprs=stmt.executeQuery("Select * from user where id="+"'"+uid+"'");
			while(uprs.next()) {
				String old=uprs.getString("ip");
				uprs.updateString("ip",ip);
				uprs.updateRow();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(stmt!=null) stmt.close();
		}
	}
}
