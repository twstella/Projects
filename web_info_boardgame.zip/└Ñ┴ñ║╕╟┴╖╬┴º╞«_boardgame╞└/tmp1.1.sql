create schema bdgame;
use bdgame;
CREATE TABLE `bdgame`.`user` (
  `id` VARCHAR(45) NOT NULL,
  `passwd` VARCHAR(45) NOT NULL,
  `ip` VARCHAR(45) NULL,
  `grp` VARCHAR(45) NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE);
  select * from user;
insert into user
  values('twstella@naver.com','98stella*',NULL,NULL);
insert into user
values('ann4913@naver.com','yeji4913',NULL,NULL);
insert into user
values('hyounso2@naver.com','hyounso2',NULL,NULL);
insert into user
values('jhlee@jejunu.ac.kr','2twins',NULL,NULL);
insert into user
values('twstella624@gmail.com','sl28721839',NULL,NULL);
insert into user
values('twsara@naver.com','98stella*',NULL,NULL);
CREATE TABLE `bdgame`.`player` (
  `id` VARCHAR(45) NOT NULL,
  `online` INT NOT NULL DEFAULT 0,
  `victory_d` INT NOT NULL DEFAULT 0,
  `defeat_d` INT NOT NULL default 0,
  `matching_score` INT NOT NULL DEFAULT 0,
  `victory_h` INT NOT NULL DEFAULT 0,
  `defeat_h` INT NOT NULL default 0,
  PRIMARY KEY (`id`));
  select * from player;
  insert into player
  values('twstella@naver.com',0,0,0,0,0,0);
insert into player
values('ann4913@naver.com',0,0,0,0,0,0);
insert into player
values('hyounso2@naver.com',0,0,0,0,0,0);
insert into player
values('jhlee@jejunu.ac.kr',0,0,0,0,0,0);
insert into player
values('twstella624@gmail.com',0,0,0,0,0,0);
insert into player
values('twsara@naver.com',0,0,0,0,0,0);
update player set defeat_d='0' where id='twsara@naver.com';

  CREATE TABLE `bdgame`.`davinci_player` (
  `id` VARCHAR(45) NOT NULL,
  `b1_num` INT NOT NULL DEFAULT 0,
  `b1_color` VARCHAR(45),
  `b2_num` INT NOT NULL DEFAULT 0,
  `b2_color` VARCHAR(45),
  `b3_num` INT NOT NULL DEFAULT 0,
  `b3_color` VARCHAR(45),
  `b4_num` INT NOT NULL DEFAULT 0,
  `b4_color` VARCHAR(45),
  `next_turn` INT NOT NULL DEFAULT 1,
  `b1_open` INT,
  `b2_open` INT,
  `b3_open` INT,
  `b4_open` INT,
  `correct` INT,
  `closed` INT,
  `max_cor` INT,
  PRIMARY KEY (`id`));
  CREATE TABLE `bdgame`.`deque2_num` (
  `grp_name` VARCHAR(45) NOT NULL,
  `b1` INT NOT NULL DEFAULT 0,
  `b2` INT NOT NULL DEFAULT 0,
  `b3` INT NOT NULL DEFAULT 0,
  `b4` INT NOT NULL DEFAULT 0,
  `b5` INT NOT NULL DEFAULT 0,
  `b6` INT NOT NULL DEFAULT 0,
  `b7` INT NOT NULL DEFAULT 0,
  `b8` INT NOT NULL DEFAULT 0,
  `b9` INT NOT NULL DEFAULT 0,
  `b10` INT NOT NULL DEFAULT 0,
  `b11` INT NOT NULL DEFAULT 0,
  `b12` INT NOT NULL DEFAULT 0,
  `b13` INT NOT NULL DEFAULT 0,
  `b14` INT NOT NULL DEFAULT 0,
  `b15` INT NOT NULL DEFAULT 0,
  `b16` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`grp_name`));
CREATE TABLE `bdgame`.`deque2_color` (
  `grp_name` VARCHAR(45) NOT NULL,
  `b1` VARCHAR(45),
  `b2` VARCHAR(45),
  `b3` VARCHAR(45),
  `b4` VARCHAR(45),
  `b5` VARCHAR(45),
  `b6` VARCHAR(45),
  `b7` VARCHAR(45),
  `b8` VARCHAR(45),
  `b9` VARCHAR(45),
  `b10` VARCHAR(45),
  `b11` VARCHAR(45),
  `b12` VARCHAR(45),
  `b13` VARCHAR(45),
  `b14` VARCHAR(45),
  `b15` VARCHAR(45),
  `b16` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
  CREATE TABLE `bdgame`.`deque3_color` (
  `grp_name` VARCHAR(45) NOT NULL,
  `b1` VARCHAR(45),
  `b2` VARCHAR(45),
  `b3` VARCHAR(45),
  `b4` VARCHAR(45),
  `b5` VARCHAR(45),
  `b6` VARCHAR(45),
  `b7` VARCHAR(45),
  `b8` VARCHAR(45),
  `b9` VARCHAR(45),
  `b10` VARCHAR(45),
  `b11` VARCHAR(45),
  `b12` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
   CREATE TABLE `bdgame`.`deque3_num` (
  `grp_name` VARCHAR(45) NOT NULL,
  `b1` INT NOT NULL DEFAULT 0,
  `b2` INT NOT NULL DEFAULT 0,
  `b3` INT NOT NULL DEFAULT 0,
  `b4` INT NOT NULL DEFAULT 0,
  `b5` INT NOT NULL DEFAULT 0,
  `b6` INT NOT NULL DEFAULT 0,
  `b7` INT NOT NULL DEFAULT 0,
  `b8` INT NOT NULL DEFAULT 0,
  `b9` INT NOT NULL DEFAULT 0,
  `b10` INT NOT NULL DEFAULT 0,
  `b11` INT NOT NULL DEFAULT 0,
  `b12` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`grp_name`));
  CREATE TABLE `bdgame`.`deque4` (
  `grp_name` VARCHAR(45) NOT NULL,
  `b1_num` INT,
  `b1_color` VARCHAR(45),
  `b2_num` INT,
  `b2_color` VARCHAR(45),
  `b3_num` INT,
  `b3_color` VARCHAR(45),
  `b4_num` INT,
  `b4_color` VARCHAR(45),
  `b5_num` INT,
  `b5_color` VARCHAR(45),
  `b6_num` INT,
  `b6_color` VARCHAR(45),
  `b7_num` INT,
  `b7_color` VARCHAR(45),
  `b8_num` INT,
  `b8_color` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
  CREATE TABLE `bdgame`.`group2` (
  `grp_name` VARCHAR(45),
  `p1` VARCHAR(45),
  `p2` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
   CREATE TABLE `bdgame`.`group3` (
  `grp_name` VARCHAR(45),
  `p1` VARCHAR(45),
  `p2` VARCHAR(45),
  `p3` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
   CREATE TABLE `bdgame`.`group4` (
  `grp_name` VARCHAR(45),
  `p1` VARCHAR(45),
  `p2` VARCHAR(45),
  `p3` VARCHAR(45),
  `p4` VARCHAR(45),
  PRIMARY KEY (`grp_name`));
  CREATE TABLE `bdgame`.`4letter_word` (
  `num` INT NOT NULL,
  `letter` VARCHAR(4) NOT NULL,
  `meaning` VARCHAR(45) ,
  PRIMARY KEY (`letter`));
  CREATE TABLE `bdgame`.`5letter_word` (
  `num` INT NOT NULL,
  `letter` VARCHAR(5) NOT NULL,
  `meaning` VARCHAR(45) ,
  PRIMARY KEY (`letter`));

CREATE TABLE `bdgame`.`6letter_word` (
  `num` INT NOT NULL,
  `letter` VARCHAR(6) NOT NULL,
  `meaning` VARCHAR(45) ,
  PRIMARY KEY (`letter`));
  alter table player add mole_score INT;
alter table player add victory_b INT;
alter table player add defeat_b INT;
update player set mole_score=0 where id not in("");
update player set victory_b=0 where id not in("");
update player set defeat_b=0 where id not in("");


alter table player add foreign key (id) references user(id);
alter table davinci_player add foreign key (id) references user(id);
alter table deque2_color add foreign key(grp_name) references group2(grp_name);
alter table deque2_num add foreign key(grp_name) references group2(grp_name);
alter table deque3_color add foreign key(grp_name) references group3(grp_name);
alter table deque3_num add foreign key(grp_name) references group3(grp_name);
alter table deque4 add foreign key(grp_name) references group4(grp_name);