1. hangman 게임을 진행하기 앞서  InputWord.jsp를 run on server ->버튼클릭 -> 화면이 하얀색으로 바뀜 -> 창 종료 후 보드게임프로젝트 실행(db단어 입력용)
2. 중복 로그인이 불가능 하오니 로그아웃을 안하고 창을 닫을 경우 추후에 로그인이 불가할 수 있습니다.
그냥 창을 닫았을 경우 해결법:
보드게임 db실행-> player테이블 선택-> online이 1로 되어있는 곳 0으로 바꾼후 apply
3. make group이나 join group 할 때 데이터베이스에 데이터가 저장되는 시간이 걸릴 수 있으니 join group 하기 전에 새로 고침 한 후 join group를 진행해 주십시오.
4. 게임 진행 시 시간마다 페이지가 새로 고침되오니 input 한 것이 새로 고침되어 초기화 되어도 짜증 내지 마십시오.
5. 중복 로그인 에러나 다른 에러 발생 시 아래에 있는 3개의 이메일 중 한 곳으로 이메일을 보내주시기 바랍니다.
6. 외부키가 있으니 데이터베이스 수정 할 때 주의 하시기 바랍니다.
2인 게임 진행 중간 창 닫은 경우
delete from deque2_color where grp_name not in('');
delete from deque2_num where grp_name not in('');
delete from group2 where grp_name not in('');
update user set grp='none' where id not in('');
update player set online=0 where id not in('');
delete from davinci_player where id not in ('');
3인 이나 4인 게임 진행 하다가 창 닫은 경우
delete from deque3_color where grp_name not in('');
delete from deque3_num where grp_name not in('');
delete from group3 where grp_name not in('');

delete from deque4 where grp_name not in('');
delete from group4 where grp_name not in('');
7. 반응형의 경우 LG G7 ThinQ를 기준으로 만들었습니다.
8. 다빈치 게임을 시작 할 때 방장(그룹을 만든 사람)이 start 버튼을 눌러야 시작이 되기 때문에 팀원인 경우
start  버튼을 눌러도 게임 페이지로 이동이 안 될 수 있습니다. 이는 오류가 아니오니 방장이 start 버튼을 누를 때까지 기다려 주십시오.
9. 본인이 방장일 경우 다른 팀원들이 home 버튼을 누르고 나가야 home 버튼이 뜹니다. 본인이 방장일 경우 다른 팀원들이 나갈 때까지 기다려 주십시오.
10. 매칭, 두더지, 야구게임, 행맨의 경우 게임을 완료하지않고 endgame을 클릭시 점수 미등록, 패배로 등록됩니다.